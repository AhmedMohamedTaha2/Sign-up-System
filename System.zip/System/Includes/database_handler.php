<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "singupandloginsystem";

        $conn = mysqli_connect($host, $username, $password, $dbname);
        if (!$conn) {
            die(mysqli_connect_error());
        } else {
            echo "Connection successful!";
        }
        mysqli_close($conn);

?>