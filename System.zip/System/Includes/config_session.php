<?php
ini_set('session.use_only_cookies', 1);
ini_set('session.use_strict_mode', 1);

session_set_cookie_params([
    'lifetime' => 1800,     // Session cookie will expire after 1800 seconds (30 minutes).
    'domain' => 'localhost', // Cookie is valid for the 'localhost' domain.
    'path' => '/',           // Cookie is available within the entire domain.
    'secure' => true,        // Cookie will be sent over secure connections only (HTTPS).
    'httponly' => true,      // Cookie is accessible only through the HTTP protocol, not by scripting languages like JavaScript.
]);

session_start(); // Starts a new session or resumes the existing one based on the session ID passed via the cookie.

if (empty($_SESSION['last_regeneration'])) {
    regenerate_session_id();
} else {
    $interval = 60 * 30; // 30 minutes expressed in seconds.
    if (time() - $_SESSION['last_regeneration'] >= $interval) {
        regenerate_session_id();
    }
}

function regenerate_session_id() {
    session_regenerate_id(); // Generates a new session ID and replaces the old one.
    $_SESSION['last_regeneration'] = time(); // Updates the last_regeneration time to the current time.
}
?>
