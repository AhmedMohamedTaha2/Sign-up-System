<?php
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  if ($_SERVER["REQUEST_METHOD"] !== "POST") {
      header("Location: ../Pages/index.php");
      die(); 
  }
  else{
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $country_key = $_POST['country_key'];
    $phone_number = $_POST['phone_number'];
    $password = $_POST['password'];
    $repeat_password = $_POST['repeat_password'];
    echo "<br> done";
  }
?>
