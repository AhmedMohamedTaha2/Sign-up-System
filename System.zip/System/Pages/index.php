<?php
    require_once "../Includes/database_handler.php";
    require_once "../Includes/config_session.php";
    require_once "../Includes/signup.include.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Assets/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="../CSS/main.css">
    <link rel="stylesheet" href="../CSS/SignUp.css">
    <title>Document</title>
</head>
<body>
    <!--? Start of navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 d-flex flex-row align-items-center justify-content-center">
        <div class="d-flex flex-row align-items-center">
            <h5 class="name">Al-Y<span>Software Training Center</span></h5>
        </div>
        <div class="d-flex flex-row align-items-center">
            <!-- Second div at the end of the navbar -->
            <button class="navbar-toggler nav-link" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon nav-link"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Course</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link sign" href="#">Sign Up</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
  <!-- ?Start of the main content -->
  <div class="container my-5 main"> <!-- Move mt-5 to container div -->
    <div class="row justify-content-center"> <!-- Center the row -->
        <div class="col-md-8 p-5"> <!-- Set the column width to 6 in medium-sized screens and above -->
            <div class="form d-flex justify-content-center flex-column align-items-center">
                <div class="formm">
                    <div class="mb-5">
                        <h1 class="h1">Create Account</h1>
                        <p class="hide-on-hover">Sign Up with Al-Y and Write Your Future in Lines of Code</p>
                    </div>
                 
                    <form method="post" action="/Includes/database_handler.php"> <!-- Add method and action to the form -->
                        <!-- Start of Full Name Input -->
                        <div class="form-group input-group">
                                <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                                <input id="full_name" name="full_name" class="form-control" placeholder="Full name" type="text">
                        </div> 
                        <!-- Start of Username Input -->
                        <div class="form-group input-group">
                            <span class="input-group-text"> <i class="fa-solid fa-at" ></i> </span>
                            <input id="username" name="username" class="form-control" placeholder="Username" type="text">
                        </div> 
                       <!-- Start and End of Email Address Input -->
                        <div class="form-group input-group">
                                <span class="input-group-text"> <i class="fa fa-envelope"></i> </span>
                                <input id="email" name="email" class="form-control" placeholder="Email address" type="email">
                        </div> 
                         <!-- Start and End of Phone Number Input -->
                        <div class="form-group input-group">
                                <span class="input-group-text"> <i class="fa fa-phone"></i> </span>
                            <select id="country_key" name="country_key" class="custom-select px-3" >
                                <option selected disabled>Country Key</option>
                                <option value="+971">+971</option>
                                <option value="+972">+972</option>
                                <option value="+198">+198</option>
                                <option value="+701">+701</option>
                            </select>
                            <input id="phone_number" name="phone_number" class="form-control" placeholder="Phone number" type="text">
                        </div>
                        <div class="form-group row">
                            <!-- Start of Create Password Input -->
                            <div class="col">
                                <div class="input-group">
                                    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                    <input id="password" name="password" class="form-control" placeholder="Create password" type="password">
                                </div>
                            </div>
                            <!-- End of Create Password Input -->
                        
                            <!-- Start of Repeat Password Input -->
                            <div class="col">
                                <div class="input-group">
                                    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                    <input id="repeat_password" name="repeat_password" class="form-control" placeholder="Repeat password" type="password">
                                </div>
                            </div>
                            <!-- End of Repeat Password Input -->
                        </div>
                        <button type="submit" class="btn btn-primary" name="submit">Sign Up</button> <!-- Changed to button and added name attribute -->
                        <div class="d-flex flex-column justify-content-center p-3">
                            <p>Have an Account ?   <a href="./login.php" class="linkk">LogIn</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


        <!-- ?Start of the footer -->
        <section class="bg-light">
            
            <div class="container">
                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-5 py-5  border-top">
                    <div class="col mb-3 text-center">
                        <div class="lc-block mb-3"><a class="navbar-brand" href="">
                                <img class="img-fluid me-1" src="../Assets/images/تصميم بدون عنوان.png" alt="my brand" width="48px" height="48px" lc-helper="image">
                            </a></div>
                        <div class="lc-block">
                            <div editable="rich">
                                <p class="text-muted">© 2024 AL-Y, Inc</p>
                            </div>
                        </div>
                    </div>
                    <div class="col offset-md-2 mb-3">
                        <div class="lc-block mb-4">
                            <div editable="rich">
                                <h4>Courses</h4>
                            </div>
                        </div>
                        <!-- /lc-block -->
                        <div class="lc-block small"> 
                            <div editable="rich" class="footer-links-list">
        
                                <ul>
                                    <li><a href="#"><i class="fa-solid fa-book" style="color: #000000;"></i> Course</a> </li>
                                    <li><a href="#"><i class="fa-solid fa-book" style="color: #000000;"></i> Course</a> </li>
                                    <li><a href="#"><i class="fa-solid fa-book" style="color: #000000;"></i> Course</a> </li>
                                    <li><a href="#"><i class="fa-solid fa-book" style="color: #000000;"></i> Course</a> </li>
                                </ul>
        
                            </div>
                        </div>
                        <!-- /lc-block -->
                    </div>
                    <div class="col mb-3">
                        <div class="lc-block mb-4">
                            <div editable="rich">
                                <h4>Social Media</h4>
                            </div>
                        </div>
                        <!-- /lc-block -->
                        <div class="lc-block small">
                            <div editable="rich" class="footer-links-list">
        
                                <ul>
                                    <li><a href="#"><i class="fa-brands fa-square-facebook" style="color: #000000;"></i> Facebook</a> </li>
                                    <li><a href="#"><i class="fa-brands fa-linkedin" style="color: #000000;"></i> linkedin</a> </li>
                                    <li><a href="#"><i class="fa-brands fa-square-instagram" style="color: #000000;"></i> Instgram</a></li>
    
                                </ul>
        
                            </div>
                        </div>
                        <!-- /lc-block -->
                    </div>
                    <div class="col mb-3">
                        <div class="lc-block mb-4">
                            <div editable="rich">
                                <h4>About us</h4>
                            </div>
                        </div>
                        <!-- /lc-block -->
                        <div class="lc-block small">
                            <div editable="rich" class="footer-links-list">
        
                                <ul>
                                    <li><a href="#"><i class="fa-solid fa-people-group" style="color: #000000;"></i> Work with us</a></li>
                                    <li><a href="#"><i class="fa-solid fa-newspaper" style="color: #000000;"></i> News</a> </li>
                                </ul>
        
                            </div>
                        </div>
                        <!-- /lc-block -->
                    </div>
                </div>
            </div>
        </section>
    <script src="./Assets/bootstrap/bootstrap.bundle.js"></script>
</body>
</html>
